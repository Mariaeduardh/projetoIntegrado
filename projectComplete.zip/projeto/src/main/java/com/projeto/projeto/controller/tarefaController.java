package com.seu_pacote.controller;

import com.seu_pacote.model.Tarefa;
import com.seu_pacote.service.TarefaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tarefas")
public class TarefaController {
    @Autowired
    private TarefaService tarefaService;

    @GetMapping("/status/{status}")
    public List<Tarefa> getByStatus(@PathVariable String status) {
        return tarefaService.buscarPorStatus(status);
    }
}
