package com.seu_pacote.controller;

import com.seu_pacote.model.Projeto;
import com.seu_pacote.service.ProjetoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/projetos")
public class ProjetoController {
    @Autowired
    private ProjetoService projetoService;

    @GetMapping("/descricao/{descricao}")
    public List<Projeto> getByDescricao(@PathVariable String descricao) {
        return projetoService.buscarPorDescricao(descricao);
    }
}
