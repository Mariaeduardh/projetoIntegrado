package com.seu_pacote.controller;

import com.seu_pacote.model.Recurso;
import com.seu_pacote.service.RecursoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/recursos")
public class RecursoController {
    @Autowired
    private RecursoService recursoService;

    @GetMapping("/nome/{nome}")
    public List<Recurso> getByNome(@PathVariable String nome) {
        return recursoService.buscarPorNome(nome);
    }
}
